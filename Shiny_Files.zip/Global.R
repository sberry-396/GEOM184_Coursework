#################################################################
## Practical 6 for GEOM184 - Open Source GIS ##
## 27/02/2025 ##
## Creating a ShinyApp ##
## Global.R ##
#################################################################


# Load vector layers
lw_points   <- st_read("C:/LocalData/sb1227/GEOM184/Part A/LW_Types.shp")
river       <- st_read("C:/LocalData/sb1227/GEOM184/Part A/RiverIsonzo.shp")
bridges     <- st_read("C:/LocalData/sb1227/GEOM184/Part A/BridgesIsonzo.shp")
clusters    <- st_read("C:/LocalData/sb1227/GEOM184/Part A/Clusters.shp")
mitigation  <- st_read("C:/LocalData/sb1227/GEOM184/Part A/MitigationSites.shp")
Dense_Forest <- st_read("C:/LocalData/sb1227/GEOM184/Part A/Dense_Forest.shp")

# Load raster layers
flow_accum <- raster("flow_accum.tif")
Heatmap        <- raster("Heatmap.tif")

# Define crs
if (is.na(crs(Heatmap))){
  crs(Heatmap)<- CRS("+proj=longlat +datum=WGS84")
}

if (is.na(crs(flow_accum))){
  crs(flow_accum)<- CRS("+proj=longlat +datum=WGS84")
}

# Convert vector layers to CRS 4326
lw_points   <- st_transform(lw_points, crs = 4326)
river       <- st_transform(river, crs = 4326)
bridges     <- st_transform(bridges, crs = 4326)
clusters    <- st_transform(clusters, crs = 4326)
mitigation  <- st_transform(mitigation, crs = 4326)
Dense_Forest <- st_transform(Dense_Forest, crs = 4326)

# Order LW types ready for color scheme
lw_points$LW_Types <- factor(lw_points$LW_Types, levels = c("Single", "Jam", "Blockage"))

# Create a palette for LW points
pal_lw <- colorFactor(
  palette = brewer.pal(n = length(levels(lw_points$LW_Types)), name = "Reds"),
  domain = lw_points$LW_Types
)

# Create a palette for clusters
pal_clusters2 <- colorFactor(
  palette = brewer.pal(n = 4, name = "Purples"),
  domain = c(2, 3, 4, 5)
)


