#################################################################
## Practical 6 for GEOM184 - Open Source GIS ##
## 27/02/2025 ##
## Creating a ShinyApp ##
## Server.R ##
#################################################################


# Leaflet map output
output$map <- renderLeaflet({
  
  # Filter clusters to remove NA values
  clusters_filtered <- clusters[!is.na(clusters$CLUSTER_SI), ]
  
  leaflet() %>%
    # Add basemap as base layer
    addProviderTiles(providers$OpenStreetMap, group = "Basemap")%>%
  
    
    # Add raster layers 
    addRasterImage(flow_accum, group = "Flow Accumulation", opacity = 0.7,
                   colors = colorNumeric(brewer.pal(9, "Blues"), domain = values(flow_accum), na.color = "transparent")) %>%
    addRasterImage(Heatmap, group = "Heatmap", opacity = 0.7) %>%
    
    # Add forest polygon
    addPolygons(data = Dense_Forest,
                group = "Dense Forest",
                color = "darkgreen",
                fillColor = "darkgreen",
                fillOpacity = 0.5,
                weight = 1) %>%
    
    # Add river polyline
    addPolylines(data = river,
                 color = "blue",
                 weight = 2,
                 opacity = 1,
                 group = "River") %>%
    
    # Add bridge layer
    addCircles(data = st_centroid(bridges),
               color = "black",
               fillOpacity = 0.9,
               weight = 2,
               radius = 50,
               popup = ~paste("<b>id:</b>", id),
               group = "Bridges") %>%
    
    # Add LW_points according to color palette in Global.R
    addCircles(data = lw_points,
               color = ~pal_lw(LW_Types),
               fillColor = ~pal_lw(LW_Types),
               fillOpacity = 0.9,
               weight = 1,
               radius = 60,
               popup = ~paste("<b>Type:</b>", LW_Types),
               group = "Large Wood") %>%
    
    # Add clusters according to color palette in Global.R
    addCircles(data = clusters_filtered,
               fillColor = ~pal_clusters2(CLUSTER_SI),
               color = "black",
               weight = 1,
               fillOpacity = 0.9,
               radius = 80,
               popup = ~paste("<b>Cluster ID:</b>", CLUSTER_ID,
                              "<br><b>Cluster Size:</b>", CLUSTER_SI),
               group = "Clusters") %>%
    
    # Add mitgation sites
    addPolylines(data = mitigation,
               color = "darkorange",
               weight = 15,
               opacity = 1,
               popup = ~paste("Info:", Info),
               group = "Mitigation Sites") %>%
    
    # Layers control to toggle layers
    addLayersControl(
      baseGroups = c("Basemap"),
      overlayGroups = c("Flow Accumulation", "Heatmap", "Dense Forest", 
                        "River", "Bridges", "Large Wood", "Clusters", "Mitigation Sites"),
      options = layersControlOptions(collapsed = FALSE)
    )
})
